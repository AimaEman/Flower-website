<?php

$conn = mysqli_connect('localhost','root','','flower_shop') or die('connection failed');

?>