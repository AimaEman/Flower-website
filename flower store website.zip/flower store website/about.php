<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php @include 'header.php'; ?>

<section class="heading">
    <h3>about us</h3>
    <p> <a href="home.php">Home</a>/About </p>
</section>

<section class="about">

    <div class="flex">

        <div class="image">
            <img src="images/about-img-1.png" alt="">
        </div>

        <div class="content">
            <h3>why choose us?</h3>
            <p>At our flower shop website, we take immense pride in curating an enchanting online floral experience like no other. With an exquisite array of handpicked blooms sourced from the finest growers, our expert florists passionately craft each arrangement, infusing it with creativity and love.</p>
            <a href="shop.php" class="btn">Shop Now</a>
        </div>

    </div>

    <div class="flex">

        <div class="content">
            <h3>what we provide?</h3>
            <p>To make every moment special, we offer timely delivery services to ensure your flowers arrive fresh and vibrant at your doorstep or the recipient's location. Whether it's a birthday surprise, anniversary celebration, or a gesture of love and appreciation, our flower shop online is dedicated to turning your moments into cherished memories.</p>
            <a href="contact.php" class="btn">Contact Us</a>
        </div>

        <div class="image">
            <img src="images/about-img-2.jpg" alt="">
        </div>

    </div>

    <div class="flex">

        <div class="image">
            <img src="images/about-img-3.jpg" alt="">
        </div>

        <div class="content">
            <h3>who we are?</h3>
            <P>At our flower shop online website, we are a team of dedicated and passionate floral enthusiasts who believe in the power of nature's beauty to touch hearts and create meaningful connections. With years of experience and a genuine love for flowers, we have cultivated an unparalleled expertise in curating stunning arrangements that speak the language of emotions.</P>
            <a href="#reviews" class="btn">Clients Reviews</a>
        </div>

    </div>

</section>

<section class="reviews" id="reviews">

    <h1 class="title">client's reviews</h1>

    <div class="box-container">

        <div class="box">
            <img src="images/pic-1.png" alt="">
            <p>Absolutely stunning floral arrangements! I've ordered from their website multiple times, and each time, the flowers have been fresh, vibrant, and beautifully arranged. </p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Burhan Ali</h3>
        </div>

        <div class="box">
            <img src="images/pic-2.png" alt="">
            <p>I needed a last-minute gift for my mother's birthday, and I stumbled upon this online flower shop. I was amazed by their wide selection and easy ordering process. </p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Aima Eman</h3>
        </div>

        <div class="box">
            <img src="images/pic-3.png" alt="">
            <p>The customer service at this flower shop is exceptional! I had a specific request for a custom arrangement, and they were more than accommodating. </p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Huzaifa Iftikhar</h3>
        </div>

        <div class="box">
            <img src="images/pic-4.png" alt="">
            <p>I can't express how grateful I am for this flower shop's sympathy arrangements. They helped me choose a thoughtful and elegant bouquet for a dear friend's memorial service.</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Harmain Iftikhar</h3>
        </div>

        <div class="box">
            <img src="images/pic-5.png" alt="">
            <p>From the moment I landed on their website, I knew I was in the right place. The layout is user-friendly, and the photos of their floral designs are simply breathtaking.</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Iftikhar Ahmad</h3>
        </div>

        <div class="box">
            <img src="images/pic-6.png" alt="">
            <p>I'm blown away by the level of care this flower shop puts into every order. Their customer service team is attentive and responsive, making sure every detail is just right. </p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Riffat Iftikhar</h3>
        </div>

    </div>

</section>











<?php @include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>